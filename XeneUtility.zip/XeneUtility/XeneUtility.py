import win32com.client
import cv2
import numpy as np
import os
import tkinter as tk
import requests
import zipfile
import subprocess 
import sys
import ctypes
from tkinter import messagebox, ttk, filedialog
from fpdf import FPDF
from PyPDF2 import PdfReader, PdfWriter


def run_as_admin():
    """Restart the program with administrator privileges."""
    if ctypes.windll.shell32.IsUserAnAdmin():
        return True  
    else:
        ctypes.windll.shell32.ShellExecuteW(None, "runas", sys.executable, " ".join(sys.argv), None, 1)
        sys.exit(0)

GHOSTSCRIPT_URL = "https://github.com/ArtifexSoftware/ghostpdl-downloads/releases/download/gs950/gs950w64.exe"
GHOSTSCRIPT_EXE = "ghostscript_installer.exe"
GHOSTSCRIPT_FOLDER = "ghostscript"

def download_ghostscript():
    """Automatically download and install Ghostscript."""
    try:
        if not os.path.exists(GHOSTSCRIPT_FOLDER):
            os.makedirs(GHOSTSCRIPT_FOLDER)

        response = requests.get(GHOSTSCRIPT_URL, stream=True)
        with open(GHOSTSCRIPT_EXE, 'wb') as f:
            for chunk in response.iter_content(chunk_size=128):
                f.write(chunk)

        print("Starting Ghostscript installation...")
        result = subprocess.run([GHOSTSCRIPT_EXE, '/S', f'/D={os.path.abspath(GHOSTSCRIPT_FOLDER)}'])

        if result.returncode == 0:
            print("Ghostscript installed successfully.")
        else:
            raise Exception(f"Error during Ghostscript installation. Error code: {result.returncode}")

        os.remove(GHOSTSCRIPT_EXE)

    except Exception as e:
        print(f"Error during Ghostscript download: {str(e)}")
        messagebox.showerror("Error", f"Error during Ghostscript download: {str(e)}")

def is_ghostscript_installed():
    """Check if Ghostscript is already installed locally."""
    return os.path.exists(os.path.join(GHOSTSCRIPT_FOLDER, "bin", "gswin64c.exe"))

def run_ghostscript(input_pdf, output_pdf):
    """Run Ghostscript to reduce PDF file size."""
    gs_path = os.path.join(GHOSTSCRIPT_FOLDER, "bin", "gswin64c.exe")
    
    gs_command = [
        gs_path,
        "-sDEVICE=pdfwrite",
        "-dCompatibilityLevel=1.4",
        "-dPDFSETTINGS=/screen",  # Can be changed to /ebook, /printer, /prepress
        "-dNOPAUSE",
        "-dQUIET",
        "-dBATCH",
        f"-sOutputFile={output_pdf}",
        input_pdf
    ]
    
    try:
        result = subprocess.run(gs_command, capture_output=True, text=True)
        if result.returncode == 0:
            print(f"Ghostscript executed successfully: {result.stdout}")
            messagebox.showinfo("Success", f"Compressed PDF saved as {output_pdf}")
        else:
            print(f"Ghostscript error: {result.stderr}")
            messagebox.showerror("Error", f"Error during compression: {result.stderr}")
    except Exception as e:
        messagebox.showerror("Error", f"Error executing Ghostscript: {str(e)}")

output_file_path = ""
input_pdf_path = ""  
output_pdf_path = ""  


def scan_document(side='front'):
    """Scan a document using the selected scanner and return the scanned file name."""
    wia = win32com.client.Dispatch("WIA.CommonDialog")
    
    scanner = wia.ShowSelectDevice(1, False, False)  # '1' indicates searching for scanners

    if not scanner:
        messagebox.showerror("Error", "Scanner not found.")
        return None

    filename = f"scanned_image_{side}.jpeg"
    if os.path.exists(filename):
        os.remove(filename)

    scanned_image = scanner.Items[1].Transfer()
    scanned_image.SaveFile(filename)
    return filename

def combine_images(front_image, back_image, output_pdf):
    """Overlay the back on the front and save the result as a PDF."""
    front = cv2.imread(front_image)
    back = cv2.imread(back_image)

    h_front, w_front, _ = front.shape
    h_back, w_back, _ = back.shape
    scaling_factor = w_front / w_back
    back_resized = cv2.resize(back, (w_front, int(h_back * scaling_factor)))

    gray_back = cv2.cvtColor(back_resized, cv2.COLOR_BGR2GRAY)
    _, mask = cv2.threshold(gray_back, 240, 255, cv2.THRESH_BINARY_INV)
    mask_inv = cv2.bitwise_not(mask)

    for i in range(3): 
        front[h_front - back_resized.shape[0]:h_front, :, i] = \
            cv2.bitwise_and(front[h_front - back_resized.shape[0]:h_front, :, i], mask_inv) + \
            cv2.bitwise_and(back_resized[:, :, i], mask)

    pdf = FPDF()
    pdf.add_page()
    temp_image = "combined_temp_image.jpeg"
    cv2.imwrite(temp_image, front)
    pdf.image(temp_image, 0, 0, 210, 297)  # A4 size
    pdf.output(output_pdf)

    os.remove(temp_image)
    os.remove(front_image)
    os.remove(back_image)

def get_scanners():
    """Return a list of available scanning devices."""
    wia = win32com.client.Dispatch("WIA.DeviceManager")
    devices = wia.DeviceInfos
    scanners = [(device.Properties["Name"].Value, device) for device in devices]
    return scanners

def update_scan_button(*args):
    """Enable or disable the scan button based on the selected scanner and output path."""
    selected_scanner = scanner_var.get()
    if selected_scanner != "Select a scanner" and output_file_path:
        scan_button.config(state=tk.NORMAL)
    else:
        scan_button.config(state=tk.DISABLED)

def select_output_file():
    """Allow the user to select the output file (path and name)."""
    global output_file_path
    file_path = filedialog.asksaveasfilename(defaultextension=".pdf", filetypes=[("PDF files", "*.pdf")])
    if file_path:
        output_file_path = file_path
        output_label.config(text=f"Save to: {output_file_path}")
    
    update_scan_button()

def start_combined_pdf():
    """Launch the interface for PDF combination."""
    global scanner_var, scan_button, output_label, scanners

    combined_pdf_window = tk.Toplevel()
    combined_pdf_window.title("Front/Back Document Scan")
    canvas = tk.Canvas(combined_pdf_window, width=400, height=350)
    canvas.pack()

    label = tk.Label(combined_pdf_window, text="Select a scanner:")
    canvas.create_window(200, 50, window=label)

    scanners = get_scanners()
    scanner_names = [scanner[0] for scanner in scanners]
    scanner_var = tk.StringVar(value="Select a scanner")
    scanner_menu = ttk.Combobox(combined_pdf_window, textvariable=scanner_var, values=scanner_names)
    scanner_menu.bind("<<ComboboxSelected>>", update_scan_button)
    canvas.create_window(200, 100, window=scanner_menu)

    save_button = tk.Button(combined_pdf_window, text="Select Output File", command=select_output_file)
    canvas.create_window(200, 150, window=save_button)

    output_label = tk.Label(combined_pdf_window, text="No file selected")
    canvas.create_window(200, 180, window=output_label)

    scan_button = tk.Button(combined_pdf_window, text="Start Scan", command=start_process, state=tk.DISABLED)
    canvas.create_window(200, 230, window=scan_button)

def start_process():
    """Start the process of scanning front and back with a graphical interface."""
    global output_pdf
    selected_scanner = scanner_var.get()
    scanner_id = next(device for name, device in scanners if name == selected_scanner)

    front_image = scan_document('front')
    if not front_image:
        return

    messagebox.showinfo("Scan Completed", "Turn the document over and press OK to scan the back...")

    back_image = scan_document('back')
    if not back_image:
        return

    output_pdf = output_file_path
    combine_images(front_image, back_image, output_pdf)
    messagebox.showinfo("Process Completed", f"The document has been saved as {output_pdf}.")

def reduce_pdf_size(input_pdf, output_pdf):
    """Reduce PDF size using Ghostscript with the local path."""
    gs_path = os.path.join(GHOSTSCRIPT_FOLDER, "bin", "gswin64c.exe")

    if not os.path.exists(gs_path):
        messagebox.showerror("Error", "Ghostscript not found in the local directory.")
        return

    gs_command = [
        gs_path,
        "-sDEVICE=pdfwrite",
        "-dCompatibilityLevel=1.4",
        "-dPDFSETTINGS=/screen",  # Can be changed to /ebook, /printer, /prepress
        "-dNOPAUSE",
        "-dQUIET",
        "-dBATCH",
        f"-sOutputFile={output_pdf}",
        input_pdf
    ]

    try:
        result = subprocess.run(gs_command, capture_output=True, text=True)
        if result.returncode == 0:
            print(f"Ghostscript executed successfully: {result.stdout}")
            messagebox.showinfo("Success", f"Compressed PDF saved as {output_pdf}")
        else:
            print(f"Ghostscript error: {result.stderr}")
            messagebox.showerror("Error", f"Error during compression: {result.stderr}")
    except Exception as e:
        print(f"Error executing Ghostscript: {e}")
        messagebox.showerror("Error", f"Error executing Ghostscript: {str(e)}")


def start_reduce_pdf():
    """Launch the interface to reduce PDF size."""
    global input_pdf_path, output_pdf_path  

    reduce_pdf_window = tk.Toplevel()
    reduce_pdf_window.title("Reduce PDF Size")

    def select_input_pdf():
        global input_pdf_path
        input_pdf_path = filedialog.askopenfilename(defaultextension=".pdf", filetypes=[("PDF files", "*.pdf")])
        if input_pdf_path:
            input_label.config(text=f"Selected File: {input_pdf_path}")
            print(f"Selected input file: {input_pdf_path}")  # Debug

    def select_output_pdf():
        global output_pdf_path
        output_pdf_path = filedialog.asksaveasfilename(defaultextension=".pdf", filetypes=[("PDF files", "*.pdf")])
        if output_pdf_path:
            output_label.config(text=f"Save to: {output_pdf_path}")
            print(f"Selected output file: {output_pdf_path}")  # Debug

    def compress_pdf():
        if input_pdf_path and output_pdf_path:
            print("Starting PDF compression")  # Debug
            
            if not run_as_admin():
                return
            
            # Check if Ghostscript is already installed
            if not is_ghostscript_installed():
                print("Ghostscript not installed. Starting download...")
                download_ghostscript()  

            reduce_pdf_size(input_pdf_path, output_pdf_path)
        else:
            print(f"input_pdf_path: {input_pdf_path}, output_pdf_path: {output_pdf_path}")  # Debug
            messagebox.showwarning("Warning", "You must select an input file and an output path!")


    canvas = tk.Canvas(reduce_pdf_window, width=400, height=250)
    canvas.pack()

    input_label = tk.Label(reduce_pdf_window, text="Select PDF to Compress")
    canvas.create_window(200, 50, window=input_label)

    input_button = tk.Button(reduce_pdf_window, text="Select PDF", command=select_input_pdf)
    canvas.create_window(200, 100, window=input_button)

    output_label = tk.Label(reduce_pdf_window, text="Select where to save the compressed PDF")
    canvas.create_window(200, 150, window=output_label)

    output_button = tk.Button(reduce_pdf_window, text="Select Destination", command=select_output_pdf)
    canvas.create_window(200, 200, window=output_button)

    compress_button = tk.Button(reduce_pdf_window, text="Reduce PDF", command=compress_pdf)
    canvas.create_window(200, 250, window=compress_button)

def main_menu():
    root = tk.Tk()
    root.title("Utility Menu")

    canvas = tk.Canvas(root, width=400, height=300)
    canvas.pack()

    combined_pdf_button = tk.Button(root, text="Open combinedPDF", command=start_combined_pdf)
    canvas.create_window(200, 100, window=combined_pdf_button)

    reduce_pdf_button = tk.Button(root, text="Reduce PDF Size", command=start_reduce_pdf)
    canvas.create_window(200, 150, window=reduce_pdf_button)

    root.mainloop()

if __name__ == "__main__":
    run_as_admin() 
    main_menu()  
